console.log('JavaScript is running');
